package file;

public class FileInfo {
	
	private String hashMD5 = null;
	private String hashSHA1 = null;
	private String name = null;
	
	public String getHashMD5() {
		return hashMD5;
	}
	public void setHashMD5(String hashMD5) {
		this.hashMD5 = hashMD5;
	}
	public String getHashSHA1() {
		return hashSHA1;
	}
	public void setHashSHA1(String hashSHA1) {
		this.hashSHA1 = hashSHA1;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
