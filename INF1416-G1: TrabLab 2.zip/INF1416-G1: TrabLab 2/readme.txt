Para executar o programa execute:

java DigestCalculator MD5 list.txt file2.txt.

Neste caso o programa verificara se ja existe um digest calculado para este arquivo.
Caso nao tenha retorna NOT_FOUND e cria.
Caso tenha, e seja igual retorna OK.
